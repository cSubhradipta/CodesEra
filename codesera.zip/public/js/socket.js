// const { socket } = require("socket.io");

// const { Socket } = require("socket.io");

let url = "https://codesera.herokuapp.com/"
var socket = io.connect(url);

// let code = codeEditor.getValue();
// let input = inputField.getValue();
// let output = outputField.getValue();
// let language = document.getElementById('lang').value;

// // function getContent(element){
// //     return element.getValue();
// // }

// // const codeArea = getContent("codeEditor");

// // codeEditor.addEventListener("keyup", (e) => {
// //     const text = codeEditor.getValue();
// //     socket.send(text);
// // });

// // socket.on('msg', (data) => {
// //     codeEditor.setValue() = data;
// // });

// io.on("ondraw", ({code, language, input, output}) => {
//     codeEditor.setValue(code);
//     language.value = language;
//     inputField.setValue(input);
//     outputField.setValue(output);
// });
const editor = document.getElementById('code');
function sendContent(){
    const text = codeEditor.getValue();
    // scrollToBottom();
    socket.send(text);
}

// window.onload = sendContent;
editor.addEventListener("keyup", sendContent);
// window.onload = sendContent;
// editor.addEventListener("keyup", (evt)=>{
//     // const text = editor.value;
//     const text = codeEditor.getValue();
    
//     // input = inputField.getValue();
//     // output = outputField.getValue();
//     // language = document.getElementById('lang').value;
//     socket.send(text);

//     // console.log(codeEditor.getValue());
//     // editorLib.init();
// });

socket.on('message', (data) => {
    codeEditor.setValue(data);
    codeEditor.clearSelection();
    // scrollToBottom();
    // codeEditor.setOptions({
    //     highlightActiveLine : true,
    //     fontSize: "18pt"
    // });
        
    // editor.value = data;
});

function scrollToBottom(){
    editor.scrollTop = editor.scrollHeight;
}