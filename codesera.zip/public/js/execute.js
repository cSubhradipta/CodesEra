let run = document.getElementById('execute');

run.addEventListener("click", ()=>{
    let code = codeEditor.getValue();
    let input = inputField.getValue();
    let output = outputField.getValue();
    let language = document.getElementById('lang').value;
    const data = { code: code, language: language, input: input };
    const url = "https://codex-api.herokuapp.com/";
    fetch(url, {
        method: 'POST', // or 'PUT'
        headers: {"Content-Type": "application/json",},
        body: JSON.stringify(data),
    })
    .then((response) => response.json())
    .then((data) => {
        console.log('Success:', data);
        outputField.setValue(data['success'] == true ? data['output']: data['error']);
        outputField.clearSelection();
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});