let express = require('express');
let app = express();

let httpServer = require("http").createServer(app);
let io = require("socket.io")(httpServer, {
    cors: {
        origin: "*"
    }
});

app.use(express.static("public"));

let PORT = process.env.PORT || 5000;
httpServer.listen(PORT, () => console.log('Server started on port ' + `${PORT}`));

io.on('connection', (socket) => {
    console.log(`${socket.id} connected`);
    console.log(io.engine.clientsCount, ' sockets connected');
    socket.on('message', (evt) => {
        console.log(evt);
        socket.broadcast.emit('message', evt);
    });
});

io.on('disconnect', (evt) => {
    console.log(`${socket.id} disconnected`);
});










// let connections = [];

// io.on('connect', (socket) => {
//     connections.push(socket);
//     console.log(`${socket.id} connected`);

//     socket.on("draw", (data) => {
//         connections.forEach((con) => {
//             if(con.id !== socket.id) {
//                 con.emit("ondraw", { code: data.code, language: data.language, input: data.input, output: data.output })
//             }
//         })
//     })

//     socket.on('disconnect', (reason) => {
//         console.log(`${socket.id} disconnected`);
//         connections = connections.filter((con) => con.id !== socket.id);
//     });
// });

